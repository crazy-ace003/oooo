// Mike Meade
public class Dealer
{
	Player dealerSeePlayeRolled = new Player();
	public void announceThrowDiceResults()
	{
		system.out.print("You have rolled a " + dealerSeePlayerRolled() + ". \n");
	}
}