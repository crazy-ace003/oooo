// Mike Meade

import java.secuirty.SecureRandom;
import java.util.Arrays;
public class Crowd
{
	SecureRandom crowdRandomNumbers = new SecureRandom();
	// create a  random number for crowd
	private int randomNumber = crowdRandomNumbers.nextInt(2);
	public void getCrowdWinResponse()
	{
		switch (randomNumber)
		{
			case 1: System.out.printf("OOOOOOOOOOOO.Winner winner chicken dinner");
					break;
			case 2: System.out.printf("you are on fire my dude");
					break;
			case 3: System.out.printf("Nice roll due, drinks on you?");
		}
	}
	public void getCrowLooseResponse
	{
		switch	(randomNumber)
		{
			case 1: System.out.printf("Today is not your day, my dude");
				break;
			case 2: System.out.printf("try blowing on the dice for better luck, my dude");
				break;
			case 3: System.out.printf("Man, you should take a break and try again in a hour");
				break;
		}
	}
	public void getCrowdPointResponse
	{
		switch (randomNumber)
		{
			case 1: System.out.printf("wow this is fresh");
				break;
			case 2: Sytem.out.printf("I jsut came up to the table caues I was curious");
				break;
		}
	}
}