// Mike MEade
import java.security.SecureRandom;

public class Craps
{
	// create random num
	public static final SecureRandom randomNumbers = new SecureRandom();

	Player playerDice = new Player();	
	Player playerRole = new Player();
	Dealer dealerRole = new Dealer();
	Player PlayerDice = new Play();
	Crowd crowdResponse = new Crowd();
	// enum types 
	private enum Status{CONTINUE, WON, LOST};

	private static final int SNAKE_EYES = 2;
	private static final int TREY = 3;
	private static final int SEVEN = 7;
	private static final int YO_LEVEN = 12;
	private static final int BOX_CARS = 12;

	public static void main(String[] args)
	{
		int myPoint = 0;
		Status gameStatus; 
		int sumOfDice = rollDice();

		switch (sumOfDice)
		{
			case SEVEN:
			case YO_LEVEN:
				gameStatus = Status.WON;
				crowdResponse.getCrowdWinResponse();
				playerRole.playWins(playerBet);
				bankRole.houses(playerBet);
				break;
			case SNAKE_EYES:
			case TREY:
				gameStatus = Status.LOST;
				break;
			case BOX_CARS:
				gameStatus = Status.Lost;
				crowdResponse.getCrowdResponse();
				playerRole.playerLoses(playerBet);
				bankRole.houseWins(playerBet);
			default:
				gameStatus = Status.CONTINUE;
				crowdResponse.getCrowdResponse();
				myPoint    = sumOfDice;
				System.out.printf("Point is %d%n", myPoint);
				break;
		}
		while (gameStatus == Status.CONTINUE)
		{
			sumOfDice = playerDice.rollDice();
			dealerRole.announceThrowDiceResults();

			// check game status
			if (sumOfDice == Status.WON)
			{
				System.out.println("Player wins. \n")
				houseBankRole.houseLoses(playerBet);
				playerRole.playerWins(playerBet);
				crowdResponse.getCrowdResponse();
				break;
			}
			else
				//if (sumOfDice == SEVEN)
			{
				System.out.println("player loses\n");
				playerRole.playerLoses(playerBet);
				bankRole.houseWins(playerBet);
				crowdResponse.getCrowLoseResponse();
				break;
			}
		}


	// roll dice
	public static int rollDice()
	{
		int dieOne  = 1 + randomNumbers.nextInt(6);
		int dieTwo  = 1 + randomNumbers.nextInt(6);

		// sum of the two die
		int sum = dieOne dieTwo;

		// display results of the roll
		System.out.printf("Player rolled %d + %d = %d%n", 
			dieOne, dieTwo, sum);
		return sum;
	}
	}
}