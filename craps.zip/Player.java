// Mike Meade


import java.util.Scanner;

public Class Player
{
	Dice throwDicePlayer = new Dice();
	Scanner betInput = new Scanner(System.in);

	// create private var
	private int betAmount;
	private int playersBank;
	
	// public
	public Player()
	{
		this.betAmount = getBetAmount();
		// Account starts at 100k ;)
		this.playerBank = 100000
	}
	// get the player bank
	public int getPlayerBank()
	{
		return playerBank;
	}
	private void setPlayersBank(int playerBank)
	{
		this.playerBank = playerBank;
	}
	// getting the amoutn the player betted
	public int getBetAmount()
	{
		return betAmount;
	}
	// player Wins !!!! :)
	public void playerWins(int betAmount)
	{
		this.playersBank = playersBank + betAmount;
	}
	// Player Looses : (
	public void playerLooses(int betAmount)
	{
		this.playersBank = playersBank - betAmount;
	}
	// thorwing and returning the dice amount
	public int throwDice()
	{
		return playerThrowDice.getTotalOfDie();
	}

	// set the bet amount
	public void setBetAmount(int betAmount)
	{
		this.betAmount = betAmount;
	}
}