// Mike Meade


// import the secureRandom
import java.security.SecureRandom;
public class Die 
{
	private int diceNums;
	// object to create the numbers
	private SecureRandom randomNumberDie = SecureRandom();
	public Die()
	{
		// this actually creates the random number
		this.diceNums = 1 + randomNumbersDie.nextInt(6)
	}
	public int getRolledDie()
	{
		return diceNums
	}
	private void setRollingDie(int diceNums)
	{
		this.diceNums = 1 + randomNumbersDie.nextInt(6);
	}
}

