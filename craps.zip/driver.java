// Mike Meade

import java.util.Scanner;
public class Driver
{
	public static void main(String args[])
	{
		// Where user inputes bet
		Scanner betInput = new Scanner(System.in)
		// Player Input
		Scanner pinput = new Scanner(System.in);
		// House Bank
		HouseBank  houseBankObj = new HouseBank();
		// player bank
		Player  playerObj = new Player();
		// craps objects
		Craps crapsObj = new Craps();

		int houseBank = houseBankObj.getHouseBank();
		int player = playerObj.getPlayerBank();
		int input = pInput.nextInt();

		while (input != 3)
		{
			switch (input)
			{
				case 1:
					System.out.println("Enter the amount you want to bet: ");
					int betAmount = inputBet.nextInput();
					playerObj.setBetAmount(betAmount);
					crapsObj.playCraps();
					houseBank = houseBankObj.getHouseBank();
					playerBank = playerObj.getPlayerBank();
					System.out.printf("  \n\t The House Money: " + houseBank + "\n\n\t Player's money: " + playerBank + "Enter an number: 1] play Crabs \n 2] Exit \n 3] Rules ");
					input = pinput.nextInt();
					break;
				case 2: 
						System.out.printf("bye");
						break;
				case 3:
					System.out.printf("\n\n 1] you bet \n 2] you roll dice \n 3] if the die comes to 7 or 11 you win, \n 4] you rll 2, 3 or 12 you loose.");
					houseBank = houseBankObj.getHouseBank();
					playerBank = playerObj.getPlayerBank();
					System.out.printf("  \n\t The House Money: " + houseBank + "\n\n\t Player's money: " + playerBank + "Enter an number: 1] play Crabs \n 2] Exit \n 3] Rules ");
					input = pinput.nextInt();
					break;
				default: 
					System.out.printf("Will go back to home screen : ");
					playerBank = playerObj.getPlayerBank();
					System.out.printf("  \n\t The House Money: " + houseBank + "\n\n\t Player's money: " + playerBank + "Enter an number: 1] play Crabs \n 2] Exit \n 3] Rules ");
					input = pinput.nextInt();
					break;
			}
		}

	}
}