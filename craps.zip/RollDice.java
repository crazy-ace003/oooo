public class Dice
{

	Die DieOne = new Die();
	Die DieTwo = new Die();

	// private vars
	private int rolledDieOne = DieOne.getRollingDie();
 	private int rolledDieTwo = DieTwo.getRollingDie();
	private int totalDie;
	

	// public 
	public Die()
	{
		this.totalDie = rolledDieOne + rolledDieTwo;
	}

	// returns the total die
	public int getTotalOfDie()
	{
		return totalDie;
	}

	// set totalofdie
	private void set(totalDie)
	{
		this.diceTotal = diceTotal;
	}
}