// mike Meade


public classHouseBank
{
	private int houseBank = 1000000;
	Player playerObjectForBank = new Player();

	private int playerWager = playerOnjectForBank.getBetAmount();
	// the house wins
	private void houseWins(int playerWager)
	{
		this.houseBank = houseBank + playerWager;
	}
	// houses looses
	public void houseLooses(int playerWager)
	{
		this.houseBank = houseBank - playerWager;
	}
	// get house bank
	public int getHouseBank()
	{
		// return huse bank
		return houseBank;
	}
}